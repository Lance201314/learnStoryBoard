//
//  CustomTagHandler.h
//  CuteAnimals
//
//  Copyright 2013 Google, Inc. All rights reserved.
//

#import "TAGContainer.h"

@interface CustomTagHandler : NSObject <TAGFunctionCallTagHandler>

@end
